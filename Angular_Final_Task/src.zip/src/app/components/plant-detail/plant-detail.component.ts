import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PlantService, Plant } from '../../services/plant.service';

@Component({
  selector: 'app-plant-detail',
  templateUrl: './plant-detail.component.html',
  styleUrls: ['./plant-detail.component.css']
})
export class PlantDetailComponent implements OnInit {
  plant: Plant | undefined;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private plantService: PlantService
  ) {}

  ngOnInit(): void {
    const plantId = this.route.snapshot.paramMap.get('id');
    this.plantService.getPlants().subscribe(plants => {
      this.plant = plants.find(p => p.id.toString() === plantId);
    });
  }

  goBack(): void {
    this.router.navigate(['/plants']);
  }
}
