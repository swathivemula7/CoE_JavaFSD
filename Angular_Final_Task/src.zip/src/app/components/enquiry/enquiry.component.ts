import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent {
  
  enquiryForm = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    email: new FormControl('', [Validators.required, Validators.email]),
    phone: new FormControl('', [Validators.required, Validators.pattern('^[0-9]{10}$')]),
    enquiryType: new FormControl('General', Validators.required),
    contactMethod: new FormControl('email', Validators.required),
    visitDate: new FormControl('', Validators.required),
    message: new FormControl('', Validators.required),
    terms: new FormControl(false, Validators.requiredTrue)
  });

  submitForm() {
    console.log("Enquiry Submitted", this.enquiryForm.value);
    if (this.enquiryForm.valid) {
      alert('Enquiry submitted successfully!');
      this.enquiryForm.reset();  // Clear the form after submission
    }
  }
}
