import { Component, OnInit } from '@angular/core';
import { PlantService, Plant } from '../../services/plant.service';

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.css']
})
export class FavoritesComponent implements OnInit {
  favoritePlants: Plant[] = [];

  constructor(private plantService: PlantService) {}

  ngOnInit(): void {
    this.loadFavoritePlants();
  }

  loadFavoritePlants() {
    const storedFavorites = localStorage.getItem('favoritePlants');
    if (storedFavorites) {
      const favoriteIds = JSON.parse(storedFavorites) as number[];

      this.plantService.getPlants().subscribe({
        next: (plants) => {
          this.favoritePlants = plants.filter(plant => favoriteIds.includes(plant.id));
        },
        error: (error) => {
          console.error('Error fetching favorite plants:', error);
        }
      });
    }
  }

  removeFromFavorites(plantId: number) {
    this.favoritePlants = this.favoritePlants.filter(plant => plant.id !== plantId);
    const updatedFavorites = this.favoritePlants.map(p => p.id);
    localStorage.setItem('favoritePlants', JSON.stringify(updatedFavorites));
  }
}
