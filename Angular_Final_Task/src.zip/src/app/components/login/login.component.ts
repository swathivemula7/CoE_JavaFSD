import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  loginError: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute) {}

  login() {
    if (this.username === 'admin' && this.password === 'admin') {
      localStorage.setItem('isLoggedIn', 'true');

      // ✅ Get returnUrl if available, otherwise go to /plants
      const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/plants';
      this.router.navigate([returnUrl]);
    } else {
      this.loginError = true;
    }
  }
}
