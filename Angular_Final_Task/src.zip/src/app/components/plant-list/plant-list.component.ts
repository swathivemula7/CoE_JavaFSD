import { Component, OnInit } from '@angular/core';
import { PlantService, Plant } from '../../services/plant.service';

@Component({
  selector: 'app-plant-list',
  templateUrl: './plant-list.component.html',
  styleUrls: ['./plant-list.component.css']
})
export class PlantListComponent implements OnInit {
  plants: Plant[] = [];
  favoriteIds: number[] = [];
  searchTerm: string = '';  // Ensure searchTerm is initialized

  constructor(private plantService: PlantService) {}

  ngOnInit(): void {
    this.loadPlants();
    this.loadFavorites();
  }

  loadPlants() {
    this.plantService.getPlants().subscribe(plants => {
      this.plants = plants;
    });
  }

  loadFavorites() {
    const storedFavorites = localStorage.getItem('favoritePlants');
    this.favoriteIds = storedFavorites ? JSON.parse(storedFavorites) : [];
  }

  toggleFavorite(plantId: number) {
    if (this.favoriteIds.includes(plantId)) {
      this.favoriteIds = this.favoriteIds.filter(id => id !== plantId);
    } else {
      this.favoriteIds.push(plantId);
    }
    localStorage.setItem('favoritePlants', JSON.stringify(this.favoriteIds));
  }
}
