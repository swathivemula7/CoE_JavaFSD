import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Plant } from '../../services/plant.service';

@Component({
  selector: 'app-plant-card',
  templateUrl: './plant-card.component.html',
  styleUrls: ['./plant-card.component.css']
})
export class PlantCardComponent {
  @Input() plant!: Plant;
  @Input() isFavorite: boolean = false;
  @Output() toggleFavorite = new EventEmitter<number>();

  onToggleFavorite() {
    this.toggleFavorite.emit(this.plant.id);
  }
}
