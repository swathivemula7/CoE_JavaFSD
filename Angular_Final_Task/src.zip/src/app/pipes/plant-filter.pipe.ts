import { Pipe, PipeTransform } from '@angular/core';
import { Plant } from '../services/plant.service';

@Pipe({
  name: 'plantFilter'
})
export class PlantFilterPipe implements PipeTransform {
  transform(plants: Plant[], searchTerm: string): Plant[] {
    if (!searchTerm) return plants;
    if (!plants) return []; // Ensure plants array is not undefined

    searchTerm = searchTerm.toLowerCase();
    return plants.filter(plant =>
      plant.name.toLowerCase().includes(searchTerm) ||
      plant.type.toLowerCase().includes(searchTerm) ||
      plant.family.toLowerCase().includes(searchTerm)
    );
  }
}
