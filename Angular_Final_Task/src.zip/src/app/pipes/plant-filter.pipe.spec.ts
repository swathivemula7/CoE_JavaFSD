import { PlantFilterPipe } from './plant-filter.pipe';

describe('PlantFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PlantFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
