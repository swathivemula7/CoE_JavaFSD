import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { PlantListComponent } from './components/plant-list/plant-list.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { PlantDetailComponent } from './components/plant-detail/plant-detail.component';
import { FavoritesComponent } from './components/favorites/favorites.component';
import { PlantFilterPipe } from './pipes/plant-filter.pipe';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './guards/auth.guard';
import { EnquiryComponent } from './components/enquiry/enquiry.component';
import { PlantCardComponent } from './components/plant-card/plant-card.component';

const routes: Routes = [
  { path: '', redirectTo: '/plants', pathMatch: 'full' },
  { path: 'plants', component: PlantListComponent },
  { path: 'plants/:id', component: PlantDetailComponent },
  { path: 'favorites', component: FavoritesComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'enquiry', component: EnquiryComponent }
 
];

@NgModule({
  declarations: [
    AppComponent,
    PlantListComponent,
    PlantDetailComponent,
    FavoritesComponent,
    PlantFilterPipe,
    LoginComponent,
    EnquiryComponent,
    PlantCardComponent
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    FormsModule,
    HttpClientModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
