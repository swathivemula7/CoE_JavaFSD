import 'dart:ui'; // Needed for BackdropFilter effect
import 'package:flutter/material.dart';
import 'api_service.dart';
import 'firebase_service.dart';
import 'home_screen.dart'; // Import the home screen

class QuestionScreen extends StatefulWidget {
  final String category;

  const QuestionScreen({Key? key, required this.category}) : super(key: key);

  @override
  _QuestionScreenState createState() => _QuestionScreenState();
}

class _QuestionScreenState extends State<QuestionScreen> {
  String? question;
  String? errorMessage;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchQuestion();
  }

  Future<void> fetchQuestion() async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
      errorMessage = null;
      question = null;
    });

    await Future.delayed(Duration(milliseconds: 500));

    try {
      String fetchedQuestion = await ApiService().fetchQuestion(widget.category);
      if (!mounted) return;

      setState(() {
        question = fetchedQuestion.isNotEmpty ? fetchedQuestion : "No question available.";
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        errorMessage = "Failed to fetch question. Please try again.";
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> saveQuestion() async {
    if (question == null || question!.isEmpty) return;

    try {
      await FirebaseService().saveQuestion(widget.category, question!);
      _showSnackbar("✅ Question saved successfully!", Colors.green);
    } catch (e) {
      _showSnackbar("❌ Failed to save question. Try again.", Colors.red);
    }
  }

  void _showSnackbar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: color),
    );
  }

  /// **🔹 Fixed Back Navigation**
  void _goToHomeScreen() {
    if (Navigator.canPop(context)) {
      Navigator.pop(context); // ✅ Safely pops the current screen
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HomeScreen()),
      ); // ✅ Only replaces if pop is not possible
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        _goToHomeScreen(); // ✅ Prevents crash
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text("${widget.category} Question"),
          backgroundColor: Colors.lightBlueAccent,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: _goToHomeScreen, // ✅ Fixed back button behavior
          ),
        ),
        body: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFE3F2FD), Color(0xFFFFFFFF)], // 🌟 Soft pastel gradient
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (isLoading)
                    _buildLoadingIndicator()
                  else
                    _buildQuestionCard(),
                  SizedBox(height: 20),
                  _buildButtons(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// **🔹 Loading Indicator**
  Widget _buildLoadingIndicator() {
    return Column(
      children: [
        CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent)),
        SizedBox(height: 16),
        Text("Fetching question...", style: TextStyle(fontSize: 18, color: Colors.blueGrey)),
      ],
    );
  }

  /// **🔹 Light Glassy Card for Question Display**
  Widget _buildQuestionCard() {
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(minHeight: 180),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.85),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2),
        ],
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Center(
          child: Text(
            errorMessage ?? question ?? "No question available",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: errorMessage != null ? Colors.red : Colors.blueGrey,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  /// **🔹 Buttons Section**
  Widget _buildButtons() {
    return Column(
      children: [
        if (errorMessage == null)
          Column(
            children: [
              CustomButton(text: "Save for Later", onTap: isLoading ? null : saveQuestion),
              CustomButton(text: "Get Another Question", onTap: isLoading ? null : fetchQuestion),
            ],
          ),
        if (errorMessage != null)
          CustomButton(text: "Retry", onTap: isLoading ? null : fetchQuestion),
      ],
    );
  }
}

/// **🔹 Updated Light-Themed Buttons**
class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;

  const CustomButton({required this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    bool isDisabled = onTap == null;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: InkWell(
        onTap: isDisabled ? null : onTap,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isDisabled
                  ? [Colors.grey[400]!, Colors.grey[300]!]
                  : [Color(0xFF64B5F6), Color(0xFFBBDEFB)],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(color: Colors.black12, blurRadius: 6, spreadRadius: 1),
            ],
          ),
          child: Center(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDisabled ? Colors.black45 : Colors.blue[900],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
