import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final CollectionReference _questionsCollection = FirebaseFirestore.instance.collection('questions');

  // ✅ Save a question to Firestore
  Future<void> saveQuestion(String category, String question) async {
    try {
      await _questionsCollection.add({
        'category': category,
        'question': question,
        'timestamp': FieldValue.serverTimestamp(), // Auto timestamp
      });
      print("Question saved successfully!");
    } catch (e) {
      print("Error saving question: $e");
    }
  }

  // ✅ Retrieve all saved questions (fixed the missing method)
  Future<List<Map<String, dynamic>>> getSavedQuestions() async {
    try {
      QuerySnapshot snapshot = await _questionsCollection.orderBy('timestamp', descending: true).get();
      return snapshot.docs.map((doc) => {
        'id': doc.id,
        'category': doc['category'],
        'question': doc['question'],
      }).toList();
    } catch (e) {
      print("Error fetching saved questions: $e");
      return [];
    }
  }

  // ✅ Retrieve questions as a real-time stream
  Stream<List<Map<String, dynamic>>> getQuestions() {
    return _questionsCollection.orderBy('timestamp', descending: true).snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
    });
  }
}
