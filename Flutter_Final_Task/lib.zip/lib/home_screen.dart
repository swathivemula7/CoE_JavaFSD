import 'package:flutter/material.dart';
import 'localization.dart';
import 'question_screen.dart';
import 'about_screen.dart';

class HomeScreen extends StatelessWidget {
  void navigateToCategory(BuildContext context, String category) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => QuestionScreen(category: category)),
    );
  }

  void navigateToAbout(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AboutScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    AppLocalizations localization = AppLocalizations.of(context)!;

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white, // ✅ Plain white background
        ),
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _AnimatedTitle(localization.translate("home_title")),
                SizedBox(height: 30),
                _buildContainer( // ✅ Solid container
                  child: Column(
                    children: [
                      CategoryButton(
                        title: localization.translate("coding_questions"),
                        onTap: () => navigateToCategory(context, "Coding"),
                      ),
                      CategoryButton(
                        title: localization.translate("aptitude_questions"),
                        onTap: () => navigateToCategory(context, "Aptitude"),
                      ),
                      CategoryButton(
                        title: localization.translate("english_speaking"),
                        onTap: () => navigateToCategory(context, "English"),
                      ),
                      SizedBox(height: 15),
                      _AnimatedTextButton(
                        text: localization.translate("about"),
                        onTap: () => navigateToAbout(context),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// **🔹 Simple White Card for Categories**
  Widget _buildContainer({required Widget child}) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white, // ✅ Solid white background instead of transparency
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 4, spreadRadius: 1), // ✅ Light shadow for subtle depth
        ],
      ),
      child: child,
    );
  }
}

/// **🔹 Animated Title with Smooth Fade-In**
class _AnimatedTitle extends StatefulWidget {
  final String text;
  const _AnimatedTitle(this.text);

  @override
  State<_AnimatedTitle> createState() => _AnimatedTitleState();
}

class _AnimatedTitleState extends State<_AnimatedTitle> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: Duration(milliseconds: 800));
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Text(
        widget.text,
        style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.black87),
      ),
    );
  }
}

/// **🔹 Soft Category Button**
class CategoryButton extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  const CategoryButton({required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: Colors.lightBlueAccent.withOpacity(0.2), // ✅ Light-colored background instead of gradient
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(color: Colors.black12, blurRadius: 4, spreadRadius: 1),
            ],
          ),
          child: Center(
            child: Text(
              title,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
          ),
        ),
      ),
    );
  }
}

/// **🔹 Minimalistic Animated Text Button**
class _AnimatedTextButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const _AnimatedTextButton({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Text(
            text,
            style: TextStyle(
              color: Colors.black87,
              fontSize: 18,
              decoration: TextDecoration.underline,
            ),
          ),
        ),
      ),
    );
  }
}
