import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'saved_questions_screen.dart';
import 'localization.dart'; // Import localization

class SettingsScreen extends StatefulWidget {
  final Function(bool) toggleTheme;
  final bool isDarkMode; // ✅ Receive current theme mode

  const SettingsScreen({required this.toggleTheme, required this.isDarkMode});

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late bool isDarkMode;

  @override
  void initState() {
    super.initState();
    isDarkMode = widget.isDarkMode; // ✅ Initialize from parent widget
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context).translate("settings"))),

      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                AppLocalizations.of(context).translate("menu"),
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("home")),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HomeScreen()),
                );
              },
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("saved_questions")),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SavedQuestionsScreen(
                      toggleTheme: widget.toggleTheme, // ✅ Pass required parameter
                      isDarkMode: widget.isDarkMode,   // ✅ Pass required parameter
                    ),
                  ),
                );
              },
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("settings")),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),

      body: Column(
        children: [
          SwitchListTile(
            title: Text(AppLocalizations.of(context).translate("dark_mode")),
            value: isDarkMode,
            onChanged: (value) {
              setState(() {
                isDarkMode = value;
              });
              widget.toggleTheme(value); // ✅ Properly toggle theme
            },
          ),
        ],
      ),
    );
  }
}
