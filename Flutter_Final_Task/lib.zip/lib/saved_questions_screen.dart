import 'package:flutter/material.dart';
import 'firebase_service.dart';
import 'home_screen.dart'; 
import 'settings_screen.dart'; 

class SavedQuestionsScreen extends StatefulWidget {
  final Function(bool) toggleTheme; 
  final bool isDarkMode; 

  const SavedQuestionsScreen({required this.toggleTheme, required this.isDarkMode});

  @override
  _SavedQuestionsScreenState createState() => _SavedQuestionsScreenState();
}

class _SavedQuestionsScreenState extends State<SavedQuestionsScreen> {
  List<Map<String, dynamic>> savedQuestions = [];
  bool isLoading = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    fetchSavedQuestions();
  }

  Future<void> fetchSavedQuestions() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      List<Map<String, dynamic>> questions = await FirebaseService().getSavedQuestions();
      setState(() {
        savedQuestions = questions;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = "Error: $e";
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Saved Questions", style: TextStyle(color: Colors.black87)), // Softer text color
        centerTitle: true,
        backgroundColor: Colors.white, 
        elevation: 2, 
        iconTheme: IconThemeData(color: Colors.black54), // Softer icon color
      ),

      drawer: Drawer(
        child: Column(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blueGrey.shade100), // Soft blue-gray background
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Text("Menu", style: TextStyle(color: Colors.black87, fontSize: 22, fontWeight: FontWeight.w600)),
              ),
            ),
            ListTile(
              title: Text("Home", style: TextStyle(color: Colors.black54)),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomeScreen()));
              },
            ),
            ListTile(
              title: Text("Saved Questions", style: TextStyle(color: Colors.black54)),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              title: Text("Settings", style: TextStyle(color: Colors.black54)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SettingsScreen(
                      toggleTheme: widget.toggleTheme, 
                      isDarkMode: widget.isDarkMode,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),

      body: Container(
        color: Colors.grey.shade100, // Soft light background
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        child: isLoading
            ? Center(child: CircularProgressIndicator(color: Colors.blueGrey))
            : errorMessage != null
                ? Center(
                    child: Text(
                      errorMessage!,
                      style: TextStyle(color: Colors.redAccent, fontSize: 18, fontWeight: FontWeight.w600),
                      textAlign: TextAlign.center,
                    ),
                  )
                : savedQuestions.isEmpty
                    ? Center(
                        child: Text(
                          "No saved questions yet.",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black54),
                        ),
                      )
                    : ListView.builder(
                        itemCount: savedQuestions.length,
                        itemBuilder: (context, index) {
                          final question = savedQuestions[index];
                          return Card(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            elevation: 2, // Softer shadow effect
                            margin: EdgeInsets.symmetric(vertical: 8),
                            color: Colors.white,
                            child: ListTile(
                              contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                              title: Text(
                                question['question'],
                                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500, color: Colors.black87),
                              ),
                              subtitle: Text(
                                "Category: ${question['category']}",
                                style: TextStyle(fontSize: 14, color: Colors.black54),
                              ),
                              trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.blueGrey),
                            ),
                          );
                        },
                      ),
      ),
      
      floatingActionButton: FloatingActionButton(
        onPressed: fetchSavedQuestions,
        backgroundColor: Colors.blueGrey.shade100,
        child: Icon(Icons.refresh, color: Colors.black87),
        tooltip: "Refresh",
      ),
    );
  }
}
