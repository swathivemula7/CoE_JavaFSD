import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'home_screen.dart';
import 'saved_questions_screen.dart';
import 'settings_screen.dart';
import 'theme.dart';
import 'localization.dart'; // Import localization

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isDarkMode = false;
  ThemeData _currentTheme = AppTheme.lightTheme;
  Locale _locale = Locale('en');

  void toggleTheme(bool isDark) {
    setState(() {
      isDarkMode = isDark;
      _currentTheme = isDark ? AppTheme.darkTheme : AppTheme.lightTheme;
    });
  }

  void setLocale(Locale newLocale) {
    setState(() {
      _locale = newLocale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Interview Prep App",
      theme: _currentTheme,
      locale: _locale,
      supportedLocales: [
        Locale('en', ''), // English
        Locale('hi', ''), // Hindi
        Locale('ta', ''), // Tamil
        Locale('te', ''), // Telugu
      ],
      localizationsDelegates: [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: HomeScreenWithDrawer(
        toggleTheme: toggleTheme,
        isDarkMode: isDarkMode,
        setLocale: setLocale,
      ),
    );
  }
}

class HomeScreenWithDrawer extends StatelessWidget {
  final Function(bool) toggleTheme;
  final bool isDarkMode;
  final Function(Locale) setLocale;

  HomeScreenWithDrawer({
    required this.toggleTheme,
    required this.isDarkMode,
    required this.setLocale,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).translate("app_title")),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                AppLocalizations.of(context).translate("menu"),
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("Home")),
              onTap: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => HomeScreen()),
              ),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("Saved Questions")),
              onTap: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => SavedQuestionsScreen(
                    toggleTheme: toggleTheme, // ✅ Pass required parameter
                    isDarkMode: isDarkMode,   // ✅ Pass required parameter
                  ),
                ),
              ),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("Settings")),
              onTap: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => SettingsScreen(
                    toggleTheme: toggleTheme, // ✅ Pass required parameter
                    isDarkMode: isDarkMode,   // ✅ Pass required parameter
                  ),
                ),
              ),
            ),
            Divider(),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("language_english")),
              onTap: () => setLocale(Locale('en')),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("language_hindi")),
              onTap: () => setLocale(Locale('hi')),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("language_tamil")),
              onTap: () => setLocale(Locale('ta')),
            ),
            ListTile(
              title: Text(AppLocalizations.of(context).translate("language_telugu")),
              onTap: () => setLocale(Locale('te')),
            ),
          ],
        ),
      ),
      body: HomeScreen(),
    );
  }
}
