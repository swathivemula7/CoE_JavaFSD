
import 'dart:math';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String apiUrl =
      "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2";
  final String apiKey = "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"; 

 Future<String> fetchQuestion(String category) async {
  String prompt = _generatePrompt(category);

  print("Generated Prompt: $prompt");
  print("API Request Time: ${DateTime.now()}");

  try {
    final response = await http.post(
      Uri.parse("$apiUrl?rand=${DateTime.now().millisecondsSinceEpoch}"), 
      headers: {
        "Authorization": "Bearer $apiKey",
        "Content-Type": "application/json",
      },
      body: jsonEncode({
        "inputs": prompt,
        "parameters": {
          "max_new_tokens": 100,
          "temperature": 0.9, // More varied responses
          "top_p": 0.95, // Encourages diverse answers
          "repetition_penalty": 1.1 // Prevents repeating questions
        }
      }),
    );

    print("Response Status Code: ${response.statusCode}");
    print("Response Body: ${response.body}");

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);

      if (data is List && data.isNotEmpty && data[0]['generated_text'] != null) {
        String generatedText = data[0]['generated_text'];

        // Remove the prompt (if included in the response)
        String cleanedQuestion = _removePrompt(generatedText, prompt);

        return cleanedQuestion.trim(); // Ensure no extra spaces
      } else {
        throw Exception("Invalid API response format");
      }
    } else {
      throw Exception("Failed to load question: ${response.statusCode} - ${response.body}");
    }
  } catch (e) {
    print("API Error: $e");
    return "Error: $e"; // Return error message to UI
  }
}

// Helper function to remove prompt from response
String _removePrompt(String responseText, String prompt) {
  if (responseText.startsWith(prompt)) {
    return responseText.replaceFirst(prompt, "").trim();
  }
  return responseText;
}


  String _generatePrompt(String category) {
    final randomId = Random().nextInt(10000);
    final timestamp = DateTime.now().millisecondsSinceEpoch;

    if (category == "Coding") {
      return "[$randomId-$timestamp] I am practicing coding in Java. So give me a single problem statement related to data structures and algorithms. Strictly, provide me only the problem statement and no other content like examples.";
    } else if (category == "Aptitude") {
      return "[$randomId-$timestamp] I am practicing aptitude, both quantitative and logical. Give me a single random question to practice. Give only question, no answer.";
    } else if (category == "English") {
      return "[$randomId-$timestamp] I need to practice English, so give me a single prompt or topic for which I could speak and practice English. Provide me only the prompt to speak on, no extra unnecessary text or words";
    }
    return "[$randomId-$timestamp] Generate a general interview question.";
  }
}
